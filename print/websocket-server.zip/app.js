const express = require("express");
const http = require("http");
const socketIo = require("socket.io");

// eslint-disable-next-line no-undef
const port = process.env.PORT || 4001;
const index = require("./routes/index");

const app = express();
app.use(index);

const server = http.createServer(app);

const io = socketIo(server);

let interval;

// const getApiAndEmit = (socket) => {
//   const response = new Date();
//   // Emitting a new message. Will be consumed by the client
//   socket.broadcast.emit("ConnectTime", response);
// };

io.on("connection", (socket, message) => {
  console.log("New client connected");
  console.info("message:", message);
  if (interval) {
    clearInterval(interval);
  }

  socket.on("PrintPhotos", (msg) => {
    console.info("msg:", msg);
    socket.broadcast.emit("GetNewPhoto", msg);
    // socket.emit("FromAPI", msg);
    // io.emit("client message", msg);
  });

  // interval = setInterval(() => getApiAndEmit(socket), 1000);

  socket.on("disconnect", () => {
    console.log("Client disconnected");
    clearInterval(interval);
  });
});

server.listen(port, () => console.log(`Listening on port ${port}`));
